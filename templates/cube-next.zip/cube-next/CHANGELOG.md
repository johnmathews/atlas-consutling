# CHANGELOG.md

## [1.1.0] - 2023-12-07

- Update Next.js to 14

## [1.0.3] - 2023-10-04

- Update Twitter icon
- Update dependencies

## [1.0.1] - 2023-05-06

- Dependencies update

## [1.0.0] - 2023-04-11

First release